The quickstarts demonstrate Jakarta EE 8 and a few additional technologies from the Red Hat JBoss Enterprise Application Platform stack. They provide small, specific, working examples that can be used as a reference for your own project.

This branch contains the latest 7.4 release of the Red Hat JBoss EAP quickstarts.

Please refer to the root README.html for additional information.